#This program processes bills at a local restaurant

#IS 115
#Due date:
#Author: 


#inputs and variables
RestaurantName = input("Enter Restaurant name: ")
ServerName = input("Enter server name: ")
BillAmount = float(input("Enter bill amount: "))
Day = input("Enter day: ") #Enter date like this "Tuesday" (no quotations)
PatronNumber = int(input("Enter number of patrons: "))
Tax = BillAmount * .085

#processing
if PatronNumber >= 8:
    Tip = BillAmount * .18
    if Day == "Tuesday":   #NOTE that the check will be case sensitive
        Date = "A discount was applied"
        Discount = BillAmount * .10
    else:
        Date = ""
        Discount = 0
    Total = (BillAmount + Tax) - Discount + Tip
else:
    Tip = BillAmount * .15
    if Day == "Tuesday":
        Date = "A discount was applied"
        Discount = BillAmount * .10
    else:
        Date = ""
        Discount = 0
    Total = (BillAmount + Tax) - Discount + Tip

#outputs
print("Restaurant Name: ", RestaurantName)
print("Server Name: ", ServerName)
print("Bill Amount: ", BillAmount)
print("Tax Amount: ", Tax)
print("Number of Patrons: ", PatronNumber)
print("Tip Amount: ", Tip)
print("Total Amount: ", Total)
print("Have a Good Day! ", Date)
