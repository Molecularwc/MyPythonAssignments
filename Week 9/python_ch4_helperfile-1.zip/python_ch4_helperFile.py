## Author: Me Me
## IS115
## Due date: 
## Time taken to complete: 45 mins

##This program will calculate the are of land as well as convert the area to acres.
counter = 0
lands = int(input("Enter number of lands to process: "))
while counter < lands:
    parcelCode = input("Enter parcel code: ")
    if parcelCode == "A-123" or parcelCode == "B-123":
        print("Error")
    else: ##This section will do the calculations
        print("Parcel code is: ", parcelCode)
        width = float(input("Enter width: "))
        length = float(input("Enter lenth: "))
        area = length * width
        print ("The area of land is %.2f  " %(area))
        acre = area/43560
        print ("The acre amount is %.2f" %(acre))
        if acre >3:
            print("Additional fees will be assessed")
    counter = counter + 1

##This program will let the user enter in a year of their choice and the
    ##temp for that year.
counter = 0
someData = False
year = int(input("Enter year: -- Input -1 if you want to exit "))
while year != -1:
    someData = True
    if year >= 0 and year < 1000:
        temp=72+.05*(year-1990)
        print ("The temp for the year " ,year,  "is " ,"%.2f"% temp, "degrees f.")
    elif year >= 1000 and year < 1800:
        temp=72+.06*(year-1990)
        print ("The temp for the year " ,year, "is " ,"%.2f"% temp, "degrees f.")
    elif year >= 1800 and year < 2050:
        temp=72+.08*(year-1990)
        print ("The temp for the year " ,year, "is " ,"%.2f"% temp, "degrees f.")
    else:
        temp=72+.1*(year-1990)
        print ("The temp for the year " ,year, "is " ,"%.2f"% temp, "degrees f.")
    year = int(input("Enter year: -- Input -1 if you want to exit "))

if someData == False:  #Note the use of the flag. someData will only become True if we have some data to process
    print("Nothing to process")


