## Author: me me
## IS115
## 
## Time: 30 mins

##This program will create an output file that can be opened with notepad
##and execute what the progarm has been given

filename = str(input("Enter a name for a file: "))
outfile = open(filename, 'w')

name = input("Enter your name - enter done when done: ")
while name != 'done':  #sentinel value
    age = int(input("Enter your age: "))
    salary = float(input("Enter your salary: "))
    email = input("Enter your email address: ")
    phone = input("Enter your phone number: ")

    outfile.write (str(name)+'\t')
    outfile.write (str(age)+'\t')
    outfile.write (str(salary)+'\t')
    outfile.write (str(email)+'\t')
    outfile.write (str(phone)+'\n')  #use \n to go to the next line

    name = input("Enter your name - enter done when done: ")
    
outfile.close()
